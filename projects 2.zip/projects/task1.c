#include <stdio.h>
#include <sys/time.h>
#include <math.h>
#include "mycom.h"

double f1(double x)
{
  return (4.0 / (1.0 + x*x));
}

double mysum(double x)
{
  return (4.0 / (1.0 + x*x + x));
}

double mysub(double x)
{
  return (4.0 / (1.0 + x*x - x));
}

double mypow(double x)
{
  return (4.0 / (x*x + pow(x, x)));
}

double myexp(double x)
{
  return (4.0 / (x*x + exp(x)));
}

double mylog(double x)
{
  return (4.0 / (x*x + log(x)));
}

double mysin(double x)
{
  return (4.0 / (x*x + sin(x)));
}


int main(int argc, char *argv[])
{	
  int nc=1000000000;
  double t1, t2, dt, sum;

  t1 = mytime(0); sum = integrate(f1, 1.0, 2.0, nc); t1 = mytime(1);
  t2 = mytime(0); sum = integrate(mysum, 1.0, 2.0, nc); t2 = mytime(1);
  dt = 1.0/dabs(t2-t1);
  printf("Time: %lf %lf sec Sum. perf.: %le GFlops\n",t1,t2,dt);

  t2 = mytime(0); sum = integrate(mysub, 1.0, 2.0, nc); t2 = mytime(1);
  dt = 1.0/dabs(t2-t1);
  printf("Time: %lf %lf sec Sub. perf.: %le GFlops\n",t1,t2,dt);

  t2 = mytime(0); sum = integrate(mypow, 1.0, 2.0, nc); t2 = mytime(1);
  dt = 1.0/dabs(t2-t1);
  printf("Time: %lf %lf sec Pow. perf.: %le GFlops\n",t1,t2,dt);

  t2 = mytime(0); sum = integrate(myexp, 1.0, 2.0, nc); t2 = mytime(1);
  dt = 1.0/dabs(t2-t1);
  printf("Time: %lf %lf sec Exp. perf.: %le GFlops\n",t1,t2,dt);

  t2 = mytime(0); sum = integrate(mylog, 1.0, 2.0, nc); t2 = mytime(1);
  dt = 1.0/dabs(t2-t1);
  printf("Time: %lf %lf sec Log. perf.: %le GFlops\n",t1,t2,dt);

  t2 = mytime(0); sum = integrate(mysin, 1.0, 2.0, nc); t2 = mytime(1);
  dt = 1.0/dabs(t2-t1);
  printf("Time: %lf %lf sec Sin. perf.: %le GFlops\n",t1,t2,dt);

  return 0;
}
