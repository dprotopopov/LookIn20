double myrand();

int mycomp(const void* a, const void* b);

void myindexes(const int np, const int ns, int* ind);

void mychebset(int mc, int nc, double *rr);

