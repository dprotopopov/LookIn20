void OutFun1D(char *name, int mode, int nx, double *x, double *f);

void OutFun1DP(char *name, int np, int mp, int nx, double *x, double *f);

void OutFun2D(char *name, int mode, int nx, int ny,
              double *x, double *y, double *f);

void OutFun2DP(char *name, int np, int mp, int nx, int ny,
              double *x, double *y, double *f);

